package com.example.service2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // button objects
    private Button buttonStart;
    private Button buttonStop;
    private MediaPlayer player; // إضافة كائن MediaPlayer

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // getting buttons from xml
        buttonStart = findViewById(R.id.buttonStart);
        buttonStop = findViewById(R.id.buttonStop);

        // attaching onclicklistener to buttons
        buttonStart.setOnClickListener(this);
        buttonStop.setOnClickListener(this);

        // إعداد MediaPlayer
        player = MediaPlayer.create(this, R.raw.my_sound); // تأكد من تغيير my_sound إلى اسم الملف الخاص بك
    }

    @Override
    public void onClick(View view) {
        if (view == buttonStart) {
            // starting service
            startService(new Intent(this, MyService.class));
            player.start(); // بدء تشغيل الصوت
            Toast.makeText(this, "Service Started", Toast.LENGTH_SHORT).show();
        } else if (view == buttonStop) {
            // stopping service
            stopService(new Intent(this, MyService.class));
            player.stop(); // إيقاف تشغيل الصوت
            Toast.makeText(this, "Service Stopped", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release(); // تحرير موارد MediaPlayer
        }
    }
}