package com.example.asynctask2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnProcess;
    ProgressBar progressBar;
    TextView txtPercentage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnProcess = findViewById(R.id.button);
        progressBar = findViewById(R.id.progressbar);
        txtPercentage = findViewById(R.id.txtpercentage);

        btnProcess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnProcess.setEnabled(false);
                new DoingAsyncTask().execute();
            }
        });
    }

    private class DoingAsyncTask extends AsyncTask<Void, Integer, Void> {
        int progressStatus;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MainActivity.this, "Invoke onPreExecute() Process", Toast.LENGTH_SHORT).show();
            progressStatus = 0;
            txtPercentage.setText("Processing 0%");
            progressBar.setProgress(0); // تأكد من إعادة تعيين شريط التقدم
        }

        @Override
        protected Void doInBackground(Void... params) {
            while (progressStatus < 100) {
                progressStatus += 5;
                publishProgress(progressStatus);
                SystemClock.sleep(200);
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressBar.setProgress(values[0]);
            txtPercentage.setText("Processing " + values[0] + "%");
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Toast.makeText(MainActivity.this, "Invoke onPostExecute() Process", Toast.LENGTH_SHORT).show();
            txtPercentage.setText("Processing complete");
            btnProcess.setEnabled(true);
        }
    }
}