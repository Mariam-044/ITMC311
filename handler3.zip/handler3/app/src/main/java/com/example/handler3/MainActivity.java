package com.example.handler3;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    ProgressBar myBar;
    TextView lblTopCaption;
    EditText txtBox1;
    Button btnDoSomething;
    int accum = 0;
    long startingMillis = System.currentTimeMillis();
    String PATIENCE = "We are currently collecting some important information." + "\nPlease hold on.";

    Handler myHandler = new Handler();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lblTopCaption = (TextView) findViewById(R.id.lblTopCaption);
        myBar = (ProgressBar) findViewById(R.id.myBar);
        myBar.setMax(100);
        txtBox1 = (EditText) findViewById(R.id.txtBox1);
        txtBox1.setHint(" Please enter some data here.");
        btnDoSomething = (Button) findViewById(R.id.btnDoSomething);
        btnDoSomething.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Editable txt = txtBox1.getText();
                Toast.makeText(getBaseContext(), "You said >> " + txt, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Create a background thread where the workload will be done
        Thread myThread1 = new Thread(backgroundTask, "backAlias1");
        myThread1.start();
        myBar.incrementProgressBy(0);
    }

    // This is the "Runnable" object responsible for UI updates
    private Runnable foregroundTask = new Runnable() {
        @Override
        public void run() {
            try {
                int progressStep = 5;
                lblTopCaption.setText(PATIENCE + "\nTotal seconds elapsed: " +
                        (System.currentTimeMillis() - startingMillis) / 1000);
                myBar.incrementProgressBy(progressStep);
                accum += progressStep;
                if (accum >= myBar.getMax()) {
                    lblTopCaption.setText("Background task is complete!");
                    myBar.setVisibility(View.INVISIBLE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    // This is the "Runnable" object that executes the background thread
    private Runnable backgroundTask = new Runnable() {
        @Override
        public void run() {
            // Busy work happens here...
            try {
                for (int n = 0; n < 20; n++) {
                    // This simulates 1 second of busy activity
                    Thread.sleep(1000);
                    // Now communicate with the main thread
                    myHandler.post(foregroundTask);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };
}